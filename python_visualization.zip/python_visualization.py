import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = {
    'Category': ['A', 'B', 'C', 'D'],
    'Values': [23, 45, 12, 36],
    'Group': ['X', 'Y', 'X', 'Y']
}

df = pd.DataFrame(data)

#Bar Plot
plt.figure(figsize=(6, 4))
sns.barplot(x='Category', y='Values', data=df)
plt.title('Bar Plot')
plt.show()

#Pie Chart
plt.figure(figsize=(6, 6))
plt.pie(df['Values'], labels=df['Category'], autopct='%1.1f%%')
plt.title('Pie Chart')
plt.show()

#Line Plot
plt.figure(figsize=(6, 4))
plt.plot(df['Category'], df['Values'], marker='o', linestyle='-', color='green')
plt.title('Line Plot')
plt.xlabel('Category')
plt.ylabel('Values')
plt.grid(True)
plt.show()

#Scatter Plot
plt.figure(figsize=(6, 4))
sns.scatterplot(x='Category', y='Values', hue='Group', data=df, s=100)
plt.title('Scatter Plot')
plt.show()

#Histogram
num_data = pd.Series([23, 45, 12, 36, 23, 45, 36, 36, 45, 12, 23])
plt.figure(figsize=(6, 4))
plt.hist(num_data, bins=5, color='lightgreen', edgecolor='black')
plt.title('Histogram')
plt.xlabel('Value')
plt.ylabel('Frequency')
plt.show()

#Box Plot
plt.figure(figsize=(6, 4))
sns.boxplot(x='Group', y='Values', data=df)
plt.title('Box Plot')
plt.show()

#Heatmap (Correlation)
sample_df = pd.DataFrame({
    'A': [1, 2, 3, 4],
    'B': [4, 3, 2, 1],
    'C': [2, 3, 2, 3]
})
plt.figure(figsize=(6, 4))
sns.heatmap(sample_df.corr(), annot=True, cmap='coolwarm')
plt.title('Heatmap (Correlation)')
plt.show()
