import pandas as pd
from prophet import Prophet
import matplotlib.pyplot as plt
import logging

logging.getLogger("cmdstanpy").setLevel(logging.WARNING)

df = pd.read_csv('sales_data.csv', encoding='ISO-8859-1')
df['ORDERDATE'] = pd.to_datetime(df['ORDERDATE'])

monthly_sales = df.resample('MS', on='ORDERDATE')['SALES'].sum().reset_index()
monthly_sales.columns = ['ds', 'y']  # Prophet expects 'ds' for date, 'y' for value

model = Prophet()
model.fit(monthly_sales)

future = model.make_future_dataframe(periods=12, freq='MS')
forecast = model.predict(future)

model.plot(forecast)
plt.title("Sales Forecast for Next 12 Months")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.tight_layout()
plt.show()

model.plot_components(forecast)
plt.tight_layout()
plt.show()

last_month = monthly_sales['ds'].max()
last_sales = monthly_sales.loc[monthly_sales['ds'] == last_month, 'y'].values[0]
predicted_next = forecast.loc[forecast['ds'] == forecast['ds'].max(), 'yhat'].values[0]

print(f"\n Last Recorded Month Sales ({last_month.strftime('%B %Y')}): ₹{last_sales:,.2f}")
print(f" Predicted Sales for Next Forecasted Month: ₹{predicted_next:,.2f}")

top_months = monthly_sales.sort_values('y', ascending=False).head(3)
print("\n Top 3 Highest Sales Months:")
print(top_months[['ds', 'y']].to_string(index=False))
