class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def show_info(self):
        print(f"Name: {self.name}, Age: {self.age}")

#Inheritance
class Student(Person):
    def __init__(self, name, age, course):
        super().__init__(name, age)
        self.course = course

    def show_info(self):
        #Polymorphism (method overriding)
        print(f"Student: {self.name}, Age: {self.age}, Course: {self.course}")

# Encapsulation
class Account:
    def __init__(self, owner, balance):
        self.owner = owner
        self.__balance = balance

    def deposit(self, amount):
        self.__balance += amount

    def get_balance(self):
        return self.__balance

#Abstraction
from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

class Square(Shape):
    def __init__(self, side):
        self.side = side

    def area(self):
        return self.side * self.side

p = Person("Arun", 20)
p.show_info()

s = Student("Bavin", "15", "Python")
s.show_info()

acc = Account("Ravi", 500)
acc.deposit(100)
print(f"Account Balance: {acc.get_balance()}")

sq = Square(4)
print(f"Area of Square: {sq.area()}")
