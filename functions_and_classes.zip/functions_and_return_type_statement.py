#Function with no arguments and no return value
def greet():
    print("Hello, welcome to Python!")

#Function with arguments and no return value
def show_info(name, age):
    print(f"Name: {name}, Age: {age}")

#Function with no arguments and a return value
def get_city():
    return "Theni"

#Function with arguments and a return value
def add_numbers(a, b):
    return a + b

#Function with default arguments
def power(base, exponent=2):
    return base ** exponent

#Function with variable-length arguments (*args)
def total_sum(*numbers):
    return sum(numbers)

#Function with keyword variable-length arguments (**kwargs)
def print_details(**info):
    for key, value in info.items():
        print(f"{key}: {value}")

#Calling all the functions
greet()

show_info("Narthani", 23)

city = get_city()
print("City:", city)

result = add_numbers(40, 10)
print("Sum:", result)

print("Power (default exponent):", power(3))
print("Power (custom exponent):", power(2, 4))

print("Total sum:", total_sum(10, 20, 30, 40))

print("User Details:")
print_details(name="Sasi", city="Chennai", age=26)
