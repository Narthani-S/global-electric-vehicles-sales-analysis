import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler

data = {
    'Name': ['Ravi', 'Barbie', 'Chandru', 'Dhina'],
    'Gender': ['Male', 'Female', 'Male', 'Male'],
    'Age': [25, None, 35, 29],
    'Salary': [50000, 60000, None, 52000]
}

df = pd.DataFrame(data)

print("Original Data:")
print(df)

df['Age'] = df['Age'].fillna(df['Age'].mean())
df['Salary'] = df['Salary'].fillna(df['Salary'].mean())

le = LabelEncoder()
df['Gender'] = le.fit_transform(df['Gender'])  # Female=0, Male=1

scaler = StandardScaler()
df[['Age', 'Salary']] = scaler.fit_transform(df[['Age', 'Salary']])

print("\nPreprocessed Data:")
print(df)
