import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.impute import SimpleImputer

df = pd.read_csv("data.csv")

# ------------------ 1. EDA ------------------

print("First 5 Rows:")
print(df.head())

print("\nData Summary:")
print(df.describe())

print("\nNull Values:")
print(df.isnull().sum())

print("\nUnique values:")
print(df.nunique())

# ------------------ 2. Data Wrangling ------------------

df = df.drop_duplicates()

num_cols = df.select_dtypes(include='number').columns
num_imputer = SimpleImputer(strategy='mean')
df[num_cols] = num_imputer.fit_transform(df[num_cols])

cat_cols = df.select_dtypes(include='object').columns
for col in cat_cols:
    df[col] = df[col].fillna(df[col].mode()[0])

df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]

for col in df.columns:
    if "date" in col or col.startswith("ds"):
        df[col] = pd.to_datetime(df[col], errors='coerce')

df.reset_index(drop=True, inplace=True)
print("Cleaned Data Preview:")
print(df.head())

# ------------------ 3. Preprocessing ------------------

df = df.sort_values('ds')

scaler = StandardScaler()
df['y_scaled'] = scaler.fit_transform(df[['y']])

print("\n Cleaned & Preprocessed Data:")
print(df.head())
