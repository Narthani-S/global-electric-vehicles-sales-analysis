# Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# 1. numpy - Create a simple array
arr = np.array([2011, 2012, 2013, 2014, 2015])
print("NumPy Array:", arr)

# 2. pandas - Create a simple DataFrame
data = {
    'Year': [2011, 2012, 2013, 2014, 2015],
    'Sales': [50, 55, 65, 70, 80]
}
df = pd.DataFrame(data)
print("\nPandas DataFrame:\n", df)

# 3. matplotlib - Plot data
plt.figure(figsize=(8, 6))
plt.plot(df['Year'], df['Sales'], marker='o')
plt.title("Year vs Sales (Matplotlib)")
plt.xlabel("Year")
plt.ylabel("Sales")
plt.grid(True)
plt.show()

# 4. seaborn - Plot with regression line
sns.lmplot(x='Year', y='Sales', data=df)
plt.title("Year vs Sales  (Seaborn)")
plt.show()



